Wednesday, 15 January 2014, 14 : 56 : 11 WIB   
======================================
Tugas II Matakulia Pemrograman Java2SE
======================================

Nama    : Mhd. Syarif
NIM     : 49013075
Jurusan : TKJMD - STEI - ITB
Email	: mhdsyarif.ms@gmail.com, m.syarif@students.itb.ac.id
Blog    : http://www.mhdsyarif.com 
-------------------------------------------------------------

=============================================================
Nama Aplikasi "Socket Programming Java Sebagai Server dan Client"
Aplikasi ini menggunakan tools sebagai berikut :
1. Java SDK versi 1.7
2. Netbeans versi 7.2
=============================================================